
import os
import requests
from flask import Flask, request, jsonify, send_from_directory

app = Flask(__name__)

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")


@app.route("/ask", methods=["POST"])
def ask():

    data = request.get_json() or {}

    question = data.get("question", "").strip()
    class_number = data.get("class", "")
    subject = data.get("subject", "")
    chapter = data.get("chapter", "")

    if not question:
        return jsonify({"answer": "Please enter a question."}), 400

    prompt = f"""
You are VIRA, the AI Learning Assistant of VANTARA EDUCATION.

Help the student understand concepts, revise, solve doubts and practise.

Class: {class_number}
Subject: {subject}
Chapter: {chapter}

Question: {question}

Answer clearly and accurately using simple student-friendly language.
Keep the response concise unless the question requires more explanation.
"""

    model = "gemini-3.6-flash"

    url = (
        "https://generativelanguage.googleapis.com/"
        f"v1beta/models/{model}:generateContent"
    )

    payload = {
        "contents": [
            {
                "parts": [
                    {"text": prompt}
                ]
            }
        ]
    }

    try:

        response = requests.post(
            url,
            headers={
                "x-goog-api-key": GEMINI_API_KEY,
                "Content-Type": "application/json"
            },
            json=payload,
            timeout=15
        )

        result = response.json()

        if response.status_code == 200:

            answer = (
                result["candidates"][0]
                ["content"]["parts"][0]["text"]
            )

            return jsonify({"answer": answer})

    except Exception as error:
        print("Error:", error)

    return jsonify({
        "answer": "VIRA is temporarily busy. Please try again."
    }), 503


@app.route("/")
def home():
    return send_from_directory(".", "index.html")


@app.route("/admin")
def admin():
    return send_from_directory(".", "admin.html")


@app.route("/<path:filename>")
def files(filename):
    return send_from_directory(".", filename)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
